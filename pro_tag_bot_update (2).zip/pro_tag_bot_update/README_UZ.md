# Pro uTag bot — yangilangan xavfsiz build

## Qo‘shilgan funksiyalar

- User yig‘ish natijasida guruh adminlari va oddiy a’zolar alohida ko‘rsatiladi.
- UTag uchun `/utag_optin` va `/utag_optout`; UTag faqat rozilik bergan userlarga ishlaydi.
- Guruh UTag: `/utag_setup` huquqlarni tekshiradi, `/utag` opt-in userlarni
  belgilaydi; `/utag so‘z1, so‘z2` so‘zli UTag qiladi.
- Owner profilida `UTag stickerlari` bo‘limi orqali sticker qo‘shish/o‘chirish.
- Guruh yordamchisi: `/grouphelp`, `/welcome on|off`, `/goodbye on|off`,
  `/greet ...`, `/farewell ...`.
- Yangi bo‘limlar uchun owner tasdig‘i: `/request group_help`,
  `/request safe_utag`, `/request pm_safe`.
- Admin Anti-Abuse: ban/kick/mute/unban harakatlari loglanadi; standart limit
  `2 ban / 60 soniya`; limit oshsa ogohlantirish yoki adminni guruhdan chiqarish.
- Action log: admin, target, amal, vaqt, sabab va bot chorasi saqlanadi.
- SQLite migratsiyasi mavjud bazani o‘chirmaydi.

## Ishga tushirish

`.env` fayliga quyidagilarni kiriting:

```env
API_ID=...
API_HASH=...
BOT_TOKEN=...
ADMIN_ID=...
```

Keyin:

```bash
python -m pip install -r requirements.txt
python pro.tag.10_updated.py
```

Bot guruhda `chat_member` update’larini olishi uchun Telegram’da kerakli
admin huquqlarini bering. Anti-Abuse choralari ham botning guruhda admin
huquqiga ega bo‘lishiga bog‘liq.

## Xavfsizlik chegarasi

Ommaviy shaxsiy-chat reydi, ruxsatsiz xabar yuborish, avtomatik ommaviy admin
qo‘shish yoki guruhni buzishga xizmat qiladigan flood/kick oqimi qo‘shilmagan.
PM Safe mavjud bo‘lsa, faqat bot bilan aloqa qilgan va rozilik bergan userlar
uchun ishlaydi; flood-limit qaytsa avtomatik to‘xtaydi.